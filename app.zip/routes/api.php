<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CityController;
use App\Http\Controllers\MajorController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\FeedbackController;
use App\Http\Controllers\ContactUsController;
use App\Http\Controllers\SocialMediaController;
use App\Http\Controllers\TermController;
use App\Http\Controllers\PlanController;
use App\Http\Controllers\NotificationController;    
use App\Http\Controllers\AlertController;
use App\Events\AlertCreated;
use App\Models\User;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\InterviewController;

// Public routes

// Auth routes
Route::post('register', [AuthController::class, 'register']);
Route::post('login', [AuthController::class, 'login'])->name('login');

// City and major routes
Route::get('cities', [CityController::class, 'index']);
Route::get('cities/{city}', [CityController::class, 'show']);
Route::get('cities/search/{query}', [CityController::class, 'search']);
Route::get('majors', [MajorController::class, 'index']);
Route::get('majors/{major}', [MajorController::class, 'show']);
Route::get('majors/search/{query}', [MajorController::class, 'search']);


// Media upload routes
Route::post('users/{id}/avatar', [UserController::class, 'uploadAvatar']);
Route::post('users/{id}/resume', [UserController::class, 'uploadResume']);
Route::post('users/{id}/documents', [UserController::class, 'uploadDocuments']);
Route::delete('users/{id}/media/{mediaId}', [UserController::class, 'deleteMedia']);

Route::get('users', [UserController::class, 'index']);
Route::get('users/{id}', [UserController::class, 'show']);

Route::get('contactUs', [ContactUsController::class, 'index']);

// terms routes
    Route::get('terms', [TermController::class, 'index']);
    Route::get('terms/{id}', [TermController::class, 'show']);

// plans routes
Route::get('plans', [PlanController::class, 'index']);
Route::get('plans/{id}', [PlanController::class, 'show']);

// Protected routes (require authentication)
Route::middleware('auth:api')->group(function () {
    
    Route::put('contactUs', [ContactUsController::class, 'update']);
    Route::resource('socialMedia', SocialMediaController::class);
    
    // General Auth routes
    Route::prefix('auth')->group(function () {
        Route::get('profile', [AuthController::class, 'profile']);
        Route::post('updateProfile', [AuthController::class, 'updateProfile']);
        Route::post('updatePassword', [AuthController::class, 'updatePassword']);
        Route::post('logout', [AuthController::class, 'logout']);
        Route::post('refresh', [AuthController::class, 'refresh']);
    });

    // feedback routes
    Route::resource('feedbacks', FeedbackController::class);

    // alert routes
    Route::resource('alerts', AlertController::class);
    Route::post('alerts/toggleRead', [AlertController::class, 'toggleRead']);

    // message routes
    Route::get('messages', [MessageController::class, 'index']);
    Route::get('messages/{id}', [MessageController::class, 'show']);
    Route::post('messages', [MessageController::class, 'store']);
    Route::post('messages/bulkActions', [MessageController::class, 'bulkActions']);

    // interview routes
    Route::get('interviews', [InterviewController::class, 'index']);
    Route::get('interviews/{id}', [InterviewController::class, 'show']);


    // Admin routes
    Route::prefix('admin')->group(function () {
        Route::apiResource('cities', CityController::class)->except(['show', 'index']);
        Route::apiResource('majors', MajorController::class)->except(['show', 'index']);
        
        // User routes
        Route::post('users', [UserController::class, 'store']);
        Route::put('users/{id}', [UserController::class, 'update']);
        Route::delete('users/{id}', [UserController::class, 'destroy']);
        Route::post('users/bulkActions', [UserController::class, 'bulkActions']);
        Route::get('users/blocklist', [UserController::class, 'blocklist']);

        Route::get('users/requestsList', [UserController::class, 'requestsList']);
        Route::get('users/acceptedRequests', [UserController::class, 'acceptedRequests']);
        Route::post('users/recruiterConfirmation', [UserController::class, 'recruiterConfirmation']);
    
        // feedback routes
        Route::prefix('feedbacks')->group(function () {    
            Route::post('/bulkActions', [FeedbackController::class, 'bulkActions']);
        }); 
        
        // term routes
        Route::post('terms', [TermController::class, 'store']);
        Route::put('terms/{id}', [TermController::class, 'update']);
        Route::delete('terms/{id}', [TermController::class, 'destroy']);

        // plan routes
        Route::post('plans', [PlanController::class, 'store']);
        Route::put('plans/{id}', [PlanController::class, 'update']);
        Route::delete('plans/{id}', [PlanController::class, 'destroy']);
        Route::post('plans/bulkActions', [PlanController::class, 'bulkActions']);
        Route::get('features', [PlanController::class, 'features']);

        // notification routes
        Route::apiResource('notifications', NotificationController::class);
        Route::post('notifications/bulkDelete', [NotificationController::class, 'bulkDelete']);
        Route::post('notifications/notify', [NotificationController::class, 'notify']);

        // reply msg
        Route::post('messages/reply', [MessageController::class, 'reply']);

        // admin export routes
        Route::post('interviews/export', [InterviewController::class, 'export']);
    });
    
    // Recruiter routes
    Route::prefix('recruiter')->group(function () {
    });

    // Candidate routes
    Route::prefix('candidate')->group(function () {
    });
});


// test pusher notifications
Route::post('/test-alert', function (Request $request) {
    $data = $request->validate([
        'user_id' => 'required|integer',
        'title'   => 'sometimes|string',
        'body'    => 'sometimes|string',
        'type'    => 'sometimes|string',
    ]);

    event(new AlertCreated([
        'title' => $data['title'] ?? 'New Notification',
        'body'  => $data['body']  ?? 'Hello from Laravel 🎉',
        'type'  => $data['type']  ?? 'info',
    ], (int) $data['user_id']));

    return [
        'ok'      => true,
        'channel' => 'user.' . (int) $data['user_id'],  // للتأكيد
        'event'   => 'alert.created',
    ];
});


